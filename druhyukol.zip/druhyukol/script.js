
function showText() {
    alert('já jsem alert');
}


function greetUser() {
    const nameInput = document.getElementById('nameinput').value;
    const greetingMessage = document.getElementById('greetingmessage');
    
    if (nameInput) {
        greetingMessage.innerHTML = `Ahoj, ${nameInput}!`;
    } else {
        greetingMessage.innerHTML = 'Zadej prosím své jméno.';
    }
}


function showTime() {
    const currentTime = new Date().toLocaleTimeString();
    document.getElementById('finaltime').innerHTML = `Čas: ${currentTime}`;
}


function showDate() {
    const currentDate = new Date().toLocaleDateString();
    document.getElementById('finaldate').innerHTML = `Dnešní datum: ${currentDate}`;
}